class Config:
    API_ID = 21669021
    API_HASH = "bcdae25b210b2cbe27c03117328648a2"
    TOKEN = "7046309155:AAH0f4ObaNcExF23RDQmrJJcjvkijQ4tae0"  
    START_PIC = "" 
    CHAT = "7013440973"    
